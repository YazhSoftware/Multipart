//
//  GradientCircularProgress.h
//  GradientCircularProgress
//
//  Created by keygx on 2015/06/24.
//  Copyright (c) 2015年 keygx. All rights reserved.
//

#import <UIKit/UIKit.h>

//! Project version number for GradientCircularProgress.
FOUNDATION_EXPORT double GradientCircularProgressVersionNumber;

//! Project version string for GradientCircularProgress.
FOUNDATION_EXPORT const unsigned char GradientCircularProgressVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <GradientCircularProgress/PublicHeader.h>


