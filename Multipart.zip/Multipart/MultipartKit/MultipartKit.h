//
//  MultipartKit.h
//  MultipartKit
//
//  Created by karuna on 4/5/16.
//  Copyright © 2016 Yazh. All rights reserved.
//

#import <UIKit/UIKit.h>

//! Project version number for MultipartKit.
FOUNDATION_EXPORT double MultipartKitVersionNumber;

//! Project version string for MultipartKit.
FOUNDATION_EXPORT const unsigned char MultipartKitVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <MultipartKit/PublicHeader.h>


